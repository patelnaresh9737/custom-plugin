<?php
/*

Plugin Name: Custom inquiry Form Plugin

Plugin URI: http://www.test.com

Description: <strong>Inquiry</strong> Form plugin </br> Front page Display Shortcode is ['inquiry-form']

Author: Naresh Patel

Version: 1.0.0 Release

Author: Naresh Patel.

Author URI: http://www.test.com

*/


include('class/register_post.php');

$contact_enquiry = new Custom_Post_Type( 'contact_inquiry' );
