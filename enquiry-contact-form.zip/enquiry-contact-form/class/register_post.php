<?php 
class Custom_Post_Type
{
    public $post_type_name;
    public $post_type_args;
    public $post_type_labels;
    
    public function __construct( $name, $args = array(), $labels = array() )
    {
       
        $this->post_type_name        = strtolower( str_replace( ' ', '_', $name ) );
        $this->post_type_args        = $args;
        $this->post_type_labels  = $labels;
        
       
            add_action( 'init', array( $this, 'register_post_type' ) );
            //add_action( 'init', array( $this, 'insert_post_data' ) );
            add_shortcode('inquiry-form', array($this, 'enquiry_form'));
            add_action('wp_enqueue_scripts', array($this,'namespace_theme_stylesheets'));
            add_action('wp_enqueue_scripts', array($this,'pva_scripts'));
            add_action( 'init', array( $this, 'custom_function_int' ) );
            
    }
    
    public  function custom_function_int(){
        add_action( 'wp_ajax_nopriv_pva_create', array($this, 'pva_create' ));
        add_action( 'wp_ajax_pva_create', array($this,'pva_create' ));
        
    }
   
    public function register_post_type()
    {
       
        $name       = ucwords( str_replace( '_', ' ', $this->post_type_name ) );
        $plural     = $name . 's';
        
       
        $labels = array_merge(
            
           
            array(
                'name'                  => _x( $plural, 'post type general name' ),
                'singular_name'         => _x( $name, 'post type singular name' ),
                'add_new'               => _x( 'Add New', strtolower( $name ) ),
                'add_new_item'          => __( 'Add New ' . $name ),
                'edit_item'             => __( 'Edit ' . $name ),
                'new_item'              => __( 'New ' . $name ),
                'all_items'             => __( 'All ' . $plural ),
                'view_item'             => __( 'View ' . $name ),
                'search_items'          => __( 'Search ' . $plural ),
                'not_found'             => __( 'No ' . strtolower( $plural ) . ' found'),
                'not_found_in_trash'    => __( 'No ' . strtolower( $plural ) . ' found in Trash'),
                'parent_item_colon'     => '',
                'menu_name'             => $plural
            ),
            
           
            $this->post_type_labels
            
            );
        $args = array_merge(
            array(
                'label'                 => $plural,
                'labels'                => $labels,
                'public'                => true,
                'show_ui'               => true,
                'map_meta_cap'          => true,
                'supports'              => array( 'title', 'editor', 'author', 'thumbnail', 'revisions', 'custom-fields'),
                'show_in_nav_menus'     => true,
                '_builtin'              => false,
            ),
            
            $this->post_type_args
            
            );
        register_post_type( $this->post_type_name, $args );
    }
    
    
    
    public function enquiry_form()
    {
        
        $html = '';
        $html = '<div class="row">';
        $html .= '<div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">';
        $html .= '<form name="contentForm" id="contentForm" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true">';
        $html .= '<div class="form schedule-assessment">';
        $html .= '<div class="row margin-top-l">';
        $html .= '<div class="form-group col-md-6">';
        $html .= '<label for="full_name" class="sr-only">Full Name: </label>';
        $html .= '<input name="full_name" id="full_name" placeholder="Full name" type="text" value="" required="required" data-error="Please enter your full name.">';
        $html .= '<div class="help-block with-errors"></div>';
        $html .= '</div>';
        $html .= '<div class="form-group col-md-6">';
        $html .= '<label for="phone_number" class="sr-only">Phone Number: </label>';
        $html .= '<input name="phone_number" id="phone_number" placeholder="Phone number" type="text" value="" required="required" data-error="Please enter your phone number">';
        $html .= '<div class="help-block with-errors"></div>';
        $html .= '</div>';
        $html .= '</div>';
        
        $html .= '<div class="row">';
        $html .= '<div class="form-group col-md-6">';
        $html .= '<label for="email" class="sr-only">Email Address: </label>';
        $html .= '<input name="email" id="email" placeholder="Email Address" type="email" value="" required="required" data-error="Please enter a valid email.">';
        $html .= '<div class="help-block with-errors"></div>';
        $html .= '</div>';
       
        $html .= '<div class="form-group text-center">';
        $html .= '<input class="submit center-block btn btn-primary" id="searchsubmit" value="Submit" name="submit" type="submit">';
        $html .= '</div>';
        $html .= '</form>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '<div id="one-way-result"></div>';
        return $html ;
        
    }
    
   function insert_post_data() {
       //session_start(); 
       if(isset($_POST['submit'])){
           
           $title     = $_POST['full_name'];
           $content   = 'test content';
           $post_type = 'contact_inquiry';
           $custom_field_1 = $_POST['email'];
           $custom_field_2 = $_POST['phone_number'];
           
           //the array of arguements to be inserted with wp_insert_post
           $new_post = array(
           'post_title'    => $title,
           'post_content'  => $content,
           'post_status'   => 'publish',
           'post_type'     => $post_type
           );
           
          
           $pid = wp_insert_post($new_post);
          
           add_post_meta($pid, 'email_id', $custom_field_1, true);
           add_post_meta($pid, 'phone_number', $custom_field_2, true);
           
               $subject = 'Enquiry Form';
               $message = 'Phone'.$_POST['phone_number'].'</br>Email id'.$_POST['email'];
               
               $adminemail = get_option( 'admin_email' );
               if(wp_mail( $adminemail , $subject, $message )){
                   $_SESSION['success']="Message successfully sent";
               }else{
                   $_SESSION['error']="Message Sending Failed, try again";
               }
              
       }else{
           
       }
     }
   
    function namespace_theme_stylesheets() {
        wp_register_style( 'mamies-wafers-bootstrap-min',  'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css', array(), null, 'all' );
        wp_enqueue_style('custom-style', plugins_url('/assets/custom.css', __FILE__), null, '1.0');
        wp_register_script( 'jquery.min.js', 'https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js', null, null, true );
        wp_enqueue_script('jquery.min.js');
        wp_register_script( 'bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js', null, null, true );
        wp_enqueue_script('bootstrap');
        wp_register_script( 'validator', 'https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js', null, null, true );
        wp_enqueue_script('validator');
}

        function pva_scripts() {
            wp_register_script( 'pva-js', plugin_dir_url( __FILE__ ) . 'assets/js/pva.js', array( 'jquery' ), '', true );
            wp_localize_script( 'pva-js', 'pva_params', array( 'pva_ajax_url' => admin_url( 'admin-ajax.php' ) ) );
            wp_enqueue_script( 'pva-js' );
    }
    
    
    function pva_create()
    {
        if(!empty($_POST['full_name']) && $_POST['phone_number'] != '' && $_POST['full_name'] !='' ){
        $post_name = $_POST['full_name'];
        $phone_number = $_POST['phone_number'];
        $email = $_POST['email'];
        
        // Create post object
        $new_pva_post = array(
        'post_type'     => 'contact_inquiry',
        'post_title'    => $post_name,
        'post_status'   => 'publish',
        'post_author'   => 1,
        );
        
        // Insert the post into the database
        $new_post_ID =  wp_insert_post( $new_pva_post );
        add_post_meta($new_post_ID, 'phone_number', $phone_number);
        add_post_meta($new_post_ID, 'email', $email);
        
        $response = array(
            'status' => '200',
            'message' => 'Message Succesfully Send',
            'new_post_ID' => $new_post_ID
        );
        
        // normally, the script expects a json respone
        
        }else{
            
          $response = array(
                'status' => '404',
                'message' => 'There are Error in this form',
                'new_post_ID' => $new_post_ID
            );
        }
        header( 'Content-Type: application/json; charset=utf-8' );
        echo json_encode( $response );
        
        exit; // important
    
    }
    
}

?>