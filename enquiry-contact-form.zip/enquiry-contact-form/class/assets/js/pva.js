$(document).ready(function(){
	$("#searchsubmit").click(function(e){
        e.preventDefault();
        var full_name = $("#full_name").val(); 
        var phone_number = $("#phone_number").val(); 
        var email = $("#email").val(); 
        
        var pva_ajax_url = pva_params.pva_ajax_url;
        $.ajax({
            type:"POST",
            url: pva_ajax_url,
            data: {
                action:'pva_create', 
                full_name : full_name,
                phone_number : phone_number,
                email : email,
            },
            success:function(response){
            	console.log(response.message);
            	jQuery('#one-way-result').html(response.message).fadeIn('slow');
                document.getElementById("contentForm").reset();
                return false;
            }
        });
    });   
});